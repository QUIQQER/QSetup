# QUIQQER Setup

With the QUIQQER Setup you can install QUIQQER fast and easily.

## How do I install QUIQQER?

+ Download the QUIQQER Setup (http://update.quiqqer.com/quiqqer.zip)
+ Extract the ZIP
+ Upload to your webserver folder

### The installation via Browser:

Open the index.php in your browser and follow the installation instructions.


### The installation via bash is quite simpler

Execute the following command:

    php quiqqer.php

Please follow the installation instructions.
Thats it.