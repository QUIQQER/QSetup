# QUIQQER Setup

With the QUIQQER Setup you can install QUIQQER fast and easily.

## 1. How do I install QUIQQER?

First you need to run the following steps:  

+ 1.1 Download the QUIQQER Setup (http://update.quiqqer.com/quiqqer.zip)
+ 1.2 Extract the ZIP
+ 1.3 Upload to your webserver folder

### 2. The installation via Browser:

Open the quiqqer.php in your browser and follow the installation instructions.


### 2. The installation via bash is quite simpler

Execute the following command:

    php quiqqer.php

Please follow the installation instructions.
Thats it.