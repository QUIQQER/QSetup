/**
 * Global locale object
 *
 * @author www.pcsg.de (Henning Leutz)
 *
 * @module Locale
 */

define('Locale', ['qui/Locale'], function(Locale)
{
    "use strict";

    return Locale;
});