# qui/classes/Locale

Die Klasse von qui/Locale.
Alle Details stehen bei [qui/Locale](index.php?file=Locale).
