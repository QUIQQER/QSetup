# qui/controls/buttons/Seperator

Mit dem Seperator Control können Buttontrenner erstellt werden.

[Beispiele](../examples/index.php?file=controls/buttons/buttons)

## Einen Seperator erstellen

```javascript
require(['qui/controls/buttons/Seperator'], function(Seperator)
{
    "use strict";

    new Seperator().inject( document.id( 'container' ) );
});
```
