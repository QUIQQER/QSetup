# qui/controls/desktop/Tasks

Ein Panel welches mehrere Panels beinhalten kann.
Durch eine Taskbar kann zwischen den Panels gewechsel werden.

## Beispiele

+ [Workspace Beispiel](../examples/index.php?file=controls/desktop/workspace_tasks)