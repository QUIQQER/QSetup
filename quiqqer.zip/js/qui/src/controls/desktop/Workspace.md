# qui/controls/desktop/Worksapce

## Beispiele

+ [Workspace Beispiel](../examples/index.php?file=controls/desktop/workspace)
+ [Workspace Beispiel](../examples/index.php?file=controls/desktop/workspace_tasks)

## Eigenschaften


## Ein Workspace erstellen

