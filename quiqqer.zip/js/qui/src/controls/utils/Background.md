# qui/controls/utils/Background

Erstellt ein einfaches halb transparentes DIV.
Wird unter anderem für qui/controls/windows/Popup verwendet
