# qui/utils/Encoding

Hilfsobjekt für Encoding Operationen.


## Wichtigste Methoden

+ encodeUTF8
+ decodeUTF8


## Verwendung

```javascript

require(['qui/utils/Encoding'], function(Encoding)
{
    var utf8 = Encoding.encodeUTF8( 'non_utf8' );
});

```

