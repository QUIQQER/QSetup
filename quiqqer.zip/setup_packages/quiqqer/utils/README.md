# QUIQQER Utils

Hilfs Klasse von QUIQQER.
Diese Klassen sollen auch unabhängig von QUIQQER funktionieren.

## composer.json

```javascript
{
    "repositories": [{
        "type": "composer",
        "url": "http://update.quiqqer.com"
    }],

    "require": {
        "quiqqer/utils" : "1.*"
    }
}
```

## PHPUnits execution

```bash
phpunit  -c phpunit/tests.xml
```

