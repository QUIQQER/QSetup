<?php

/**
 * This file contains \QUI\Utils\Bool
 */

namespace QUI\Utils;

/**
 * Helper for bool type handling
 *
 * @author  www.pcsg.de (Henning Leutz
 * @package com.pcsg.qui.utils
 *
 * @deprecated
 */

class Bool extends BoolHelper
{

}
