<?php

/**
 * This file contains QUI\Utils\String
 */

namespace QUI\Utils;

use QUI;

/**
 * Helper for string handling
 *
 * @author  www.pcsg.de (Henning Leutz
 * @package com.pcsg.qutils
 *
 * @deprecated use StringHelper
 */
class String extends StringHelper
{

}
